package service;

import java.math.BigDecimal;

public interface TradeCalculatorService {

	BigDecimal calculateGBCEAllShareIndex();
}