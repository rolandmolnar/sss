package service;

import domain.Trade;

public interface TradeRecorderService {

	void recordTrade(Trade trade);
}